#!/bin/bash
java -jar Plombier.jar
